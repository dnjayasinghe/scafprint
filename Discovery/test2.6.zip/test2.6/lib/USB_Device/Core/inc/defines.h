/*
 * defines.h
 *
 *  Created on: Jun 18, 2015
 *      Author: Darshana
 */

#ifndef DEFINES_H_
#define DEFINES_H_


#define USB_VCP_RECEIVE_BUFFER_LENGTH        128

#endif /* DEFINES_H_ */
